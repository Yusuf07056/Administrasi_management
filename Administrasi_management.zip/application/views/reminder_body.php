<section class="home-section" style="text-align: center;">
	<div class="text">UPLOAD CV</div>
	<br>
	<div class="text">
		<form action="" method="post">
			<table>
				<thead>
					<tr>
						<th>
							<img src="<?= base_url('asset/image/kakkichan2.jpg') ?>" alt="" style="width:100px; height: 100px;">
						</th>

					</tr>
					<tr>
						<th>
							<span>NAMA</span>
						</th>
					</tr>
					<tr>
						<th>
							<span>ID</span>
						</th>
					</tr>
				</thead>
			</table>
			<input type="button" value="EDIT" class="btn_submit">
		</form>
	</div>
</section>
