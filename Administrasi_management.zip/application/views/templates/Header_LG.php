<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<script src="<?= base_url('https://kit.fontawesome.com/64d58efce2.js') ?>" crossorigin="anonymous"></script>
	<link rel="icon" href="<?= base_url('asset/image/favicon.ico') ?>" type="image/x-icon">
	<link rel="stylesheet" href="<?= base_url('asset/css/Style.css') ?>" />
	<title>Sign in & Sign up Form</title>
</head>

<body>
	
