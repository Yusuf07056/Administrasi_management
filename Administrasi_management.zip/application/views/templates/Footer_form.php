<script src="<?= base_url('asset/js/lamaran.js') ?>"></script>
<script>
	document.getElementById("Utama").click();
</script>
</body>

</html>
