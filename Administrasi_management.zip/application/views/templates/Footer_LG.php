<script src="<?= base_url('asset/js/App.js') ?>"></script>
</body>

</html>
