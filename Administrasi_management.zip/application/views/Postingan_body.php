
<section class="home-section">
	<div class="text">POSTINGAN</div>
	<br>
	<div class="text">
		<form action="" method="post">
			<input type="text" name="judul_post" id="judul_post" placeholder="JUDUL">
			<br>
			STATUS
			<select name="jenis_post" id="jenis_post">
				<option value="1">PUBLISH</option>
				<option value="2">DRAFT</option>
			</select>
			<br>
			<textarea name="" id="" cols="30" rows="10" placeholder="ISI" style="resize: none;"></textarea>
			<br>
			<input type="button" value="FINISH" class="btn_submit">
		</form>
	</div>
</section>
